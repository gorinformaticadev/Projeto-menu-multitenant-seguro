import React from 'react';
import { DemoCreate } from '../components/DemoCreate';
import { Box } from '@mui/material';

export default function DemoCreatePage() {
  return (
    <Box>
      <DemoCreate />
    </Box>
  );
}
