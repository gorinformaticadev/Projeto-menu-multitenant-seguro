import React from 'react';
import { SistemaDashboard } from '../components/SistemaDashboard';
import { Box } from '@mui/material';

export default function SistemaDashboardPage() {
  return (
    <Box>
      <SistemaDashboard />
    </Box>
  );
}