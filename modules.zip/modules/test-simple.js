// Teste simples
console.log('API funcionando!');
window.testSimple = true;