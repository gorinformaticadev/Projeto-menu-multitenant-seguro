// Arquivo de teste simples
console.log('Teste de carregamento de módulo funcionando!');
window.testModule = function() {
  return { message: 'API route funcionando!' };
};